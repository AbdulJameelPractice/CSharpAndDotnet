﻿

using AutoDefaultStruct;

Console.WriteLine(new ToDoItem());

Console.ReadLine();