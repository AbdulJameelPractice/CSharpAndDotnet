﻿
Console.WriteLine(new Address());

Person person = new Person()
{
    FirstName = "Gill",
    LastName = "Cleeren",
    Street = "Some street",
    City = "Antwerp",
    Number = "231",
    Country = "Belgium",
    PostalCode = "1111"
};


Console.WriteLine(person.GetPersonDetails());





Console.ReadLine();