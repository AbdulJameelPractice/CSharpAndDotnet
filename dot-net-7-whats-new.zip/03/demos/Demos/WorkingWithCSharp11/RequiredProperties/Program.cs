﻿

//Person p1 = new Person() { FirstName = "Gill", LastName = "Cleeren", _Age = 40 };
Employee e1 = new Employee("John", "Smith", "Manager");

