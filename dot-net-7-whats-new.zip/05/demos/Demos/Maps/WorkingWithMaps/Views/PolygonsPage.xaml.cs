﻿namespace WorkingWithMaps.Views;

public partial class PolygonsPage : ContentPage
{
    public PolygonsPage()
    {
        InitializeComponent();
    }
}