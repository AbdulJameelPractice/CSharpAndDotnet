﻿namespace WorkingWithMaps.Views;

public partial class MapRegionPage : ContentPage
{
    public MapRegionPage()
    {
        InitializeComponent();
    }
}


