﻿namespace WorkingWithMaps.Views;

public partial class CirclePage : ContentPage
{
    public CirclePage()
    {
        InitializeComponent();
    }
}
