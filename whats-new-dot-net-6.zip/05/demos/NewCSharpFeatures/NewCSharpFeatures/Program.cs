﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

var appName = TestInterpolatedStrings();
Console.WriteLine(appName);

Console.ReadLine();

string TestInterpolatedStrings()
{
    const string appName = "Bethany's Pie Shop HRM";
    const string appVersion = "V1.1";
    const string fullAppName = $"About {appName} {appVersion}";

    return fullAppName;
}