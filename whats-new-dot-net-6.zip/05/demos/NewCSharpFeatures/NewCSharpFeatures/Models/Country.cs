﻿

namespace NewCSharpFeatures.Models;

public class Country
{
    public int CountryId { get; set; }
    [Required]
    [StringLength(50, ErrorMessage = "First name is too long.")]
    public string Name { get; set; }
}
