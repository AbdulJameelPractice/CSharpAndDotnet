﻿
namespace NewCSharpFeatures.Models
{
    public enum MaritalStatus
    {
        Married,
        Single,
        Other
    }
}