﻿
namespace NewCSharpFeatures.Models
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}