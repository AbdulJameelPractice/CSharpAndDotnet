﻿
namespace NewCSharpFeatures.Models
{
    public class JobCategory
    {
        public int JobCategoryId { get; set; }
        public string JobCategoryName { get; set; }
    }
}