﻿
var myDate = new DateOnly(2021, 12, 24);
Console.WriteLine(myDate);  
Console.WriteLine(myDate.ToLongDateString());  

var today  = DateOnly.FromDateTime(DateTime.Now);
Console.WriteLine(today);   

var oneYearFromToday = today.AddYears(1);
Console.WriteLine(oneYearFromToday);    

var myTime = new TimeOnly(9, 0);
Console.WriteLine(myTime);  

var startTime = new TimeOnly(10, 0);
var endTime = new TimeOnly(10, 30, 25);

var diffTime = endTime - startTime; 
Console.WriteLine(diffTime);
Console.WriteLine(endTime > startTime);

Console.ReadLine(); 
