var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddIniFile("appsettings.ini");
builder.Logging.AddJsonConsole();
builder.Services.AddMemoryCache();

builder.WebHost.UseWebRoot("webroot");

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

ILogger logger = app.Logger;
IHostApplicationLifetime lifetime = app.Lifetime;
IWebHostEnvironment env = app.Environment;

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
