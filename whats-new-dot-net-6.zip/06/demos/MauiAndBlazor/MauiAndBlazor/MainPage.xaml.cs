﻿using Microsoft.Maui.Controls;
using System;

namespace MauiAndBlazor
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
