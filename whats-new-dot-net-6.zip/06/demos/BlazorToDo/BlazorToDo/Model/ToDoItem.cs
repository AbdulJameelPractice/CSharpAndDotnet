﻿namespace BlazorToDo.Model
{
    public class ToDoItem
    {
        public string Title { get; set; }
        public string Description {  get; set; }
        public DateOnly DateCreated { get; set; }

    }
}
