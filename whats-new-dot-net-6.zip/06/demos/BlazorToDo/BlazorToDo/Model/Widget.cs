﻿namespace BlazorToDo.Model
{
    public record Widget
    {
        public Type? Type;
    }
}
