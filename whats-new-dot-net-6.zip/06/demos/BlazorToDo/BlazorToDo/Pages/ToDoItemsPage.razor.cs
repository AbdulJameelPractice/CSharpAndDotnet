﻿using BlazorToDo.Model;
using Microsoft.AspNetCore.Components;

namespace BlazorToDo.Pages
{
    public partial class ToDoItemsPage
    {
        public IList<ToDoItem> ToDoItems { get; set; }
        public bool Loading { get; set; }

        [Parameter]
        [SupplyParameterFromQuery(Name = "Message")]
        public string Message { get; set; }

        protected override void OnInitialized()
        {
            Loading = true;

            ToDoItems = new List<ToDoItem>()
            {
                new ToDoItem(){Title = "Get milk", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."}, 
                new ToDoItem(){Title = "Learn Blazor", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."}, 
                new ToDoItem(){Title = "Create an app with Blazor", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."},
                new ToDoItem(){Title = "", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."}
            };

            Loading = false; 
        }
    }
}
