﻿using BlazorToDo.Components;

namespace BlazorToDo.Pages
{
    public partial class Index
    {
        private List<Type> widgets = new List<Type> { typeof(WidgetOne), typeof(WidgetTwo), typeof(WidgetThree) };

    }
}
