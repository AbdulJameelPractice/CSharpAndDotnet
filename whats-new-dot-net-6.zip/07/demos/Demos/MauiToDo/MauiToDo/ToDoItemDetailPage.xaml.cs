﻿using MauiToDo.Model;
using Microsoft.Maui.Controls;
using System;

namespace MauiToDo
{
    public partial class ToDoItemDetailPage : ContentPage
    {
        public ToDoItemDetailPage()
        {
            InitializeComponent();
        }

        private async void SaveButtonClicked(object sender, EventArgs e)
        {
            var toDoItem = (ToDoItem)BindingContext;
            if (toDoItem.Id == 0)
            {
                new ToDoItemRepository().CreateNewToDoItem(toDoItem);
            }
            else
            {
                new ToDoItemRepository().UpdateItem(toDoItem);
            }
            await Navigation.PopAsync();
        }

        private async void DeleteButtonClicked(object sender, EventArgs e)
        {
            var toDoItem = (ToDoItem)BindingContext;

            new ToDoItemRepository().DeleteItem(toDoItem.Id);
            await Navigation.PopAsync();
        }

        private async void CancelButtonClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}