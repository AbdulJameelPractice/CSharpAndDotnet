﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MauiToDo.Model
{
    public class ToDoItemRepository
    {
        private static List<ToDoItem> _toDoItems;
        public ToDoItemRepository()
        {
            if (_toDoItems == null)
            {
                _toDoItems = new List<ToDoItem>()
                {
                    new ToDoItem(){Id = 1, Title = "Get milk", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit.", DateCreated= DateOnly.FromDateTime(DateTime.Now) },
                    new ToDoItem(){Id = 2, Title = "Learn Maui", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit.", DateCreated= DateOnly.FromDateTime(DateTime.Now)},
                    new ToDoItem(){Id = 3, Title = "Create an app with Maui", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit.", DateCreated= DateOnly.FromDateTime(DateTime.Now)},
                    new ToDoItem(){Id = 4, Title = "Follow C# course on Pluralsight", Description="Lorem ipsum dolor sit amet, consectetur adipiscing elit.", DateCreated= DateOnly.FromDateTime(DateTime.Now)}
                };
            }
        }

        public List<ToDoItem> GetAll()
        {
            return _toDoItems.ToList();
        }

        public ToDoItem GetById(int id)
        {
            return _toDoItems.FirstOrDefault(i => i.Id == id);
        }

        public void CreateNewToDoItem(ToDoItem item)
        {
            int nextId = _toDoItems.Max(i => i.Id);
            item.Id = nextId + 1;
            _toDoItems.Add(item);
        }

        public void UpdateItem(ToDoItem item)
        {
            var itemToUpdate = _toDoItems.FirstOrDefault(i => i.Id == item.Id);

            ArgumentNullException.ThrowIfNull(itemToUpdate);

            itemToUpdate.DateCreated = item.DateCreated;
            itemToUpdate.Description = item.Description;
            itemToUpdate.Title = item.Title;
            itemToUpdate.Done = item.Done;
        }

        public void DeleteItem(int id)
        {
            var itemToDelete = _toDoItems.FirstOrDefault(i => i.Id == id);

            ArgumentNullException.ThrowIfNull(itemToDelete);

            _toDoItems.Remove(itemToDelete);
        }
    }
}
