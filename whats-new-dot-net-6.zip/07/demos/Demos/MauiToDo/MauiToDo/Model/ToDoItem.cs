﻿using System;

namespace MauiToDo.Model
{
    public class ToDoItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateOnly DateCreated { get; set; }
        public bool Done { get; set; }
    }
}
