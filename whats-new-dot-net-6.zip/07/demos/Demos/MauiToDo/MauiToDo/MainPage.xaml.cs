﻿using MauiToDo.Model;
using Microsoft.Maui.Controls;
using System;

namespace MauiToDo
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var repo = new ToDoItemRepository();
            ToDoListView.ItemsSource = repo.GetAll();
        }

        public async void ToDoItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ToDoItem selectedToDo = e.SelectedItem as ToDoItem;
            ArgumentNullException.ThrowIfNull(selectedToDo);

            await Navigation.PushAsync(new ToDoItemDetailPage
            {
                BindingContext = selectedToDo
            });
        }

        public async void AddButtonClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ToDoItemDetailPage
            {
                BindingContext = new ToDoItem()
            });
        }
    }
}
