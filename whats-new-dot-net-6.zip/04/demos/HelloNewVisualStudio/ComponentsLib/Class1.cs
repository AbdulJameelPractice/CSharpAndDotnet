﻿namespace ComponentsLib
{
    public class Class1
    {

    }
}