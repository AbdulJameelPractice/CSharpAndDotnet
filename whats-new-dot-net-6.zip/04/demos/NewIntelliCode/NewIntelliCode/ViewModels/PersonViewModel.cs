﻿namespace NewIntelliCode.ViewModels
{
    public class PersonViewModel
    {
        public int Age { get; set; }
        public string? Name {  get; set; }
        public string? Title {  get; set; }  
        public string? Description {  get; set; }
        public string? Email {  get; set; }  

    }
}
