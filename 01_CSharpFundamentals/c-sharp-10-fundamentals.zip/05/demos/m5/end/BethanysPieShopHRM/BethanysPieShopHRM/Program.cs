﻿
using BethanysPieShopHRM;

Console.WriteLine("Welcome to Bethany's Pie Shop HRM");


//int amount = 1234;
//int months = 12;
//int bonus = 1000;

//int yearlyWage = Utilities.CalculateYearlyWage(amount, months);
//int yearlyWageWithBonus = Utilities.CalculateYearlyWage(amount, months, bonus);

//Console.WriteLine($"Yearly wage: {yearlyWage}");


//double amountDouble = 1500.0;
//double monthsDouble = 12;
//double bonusDouble = 1000;

//double yearlyWageWithBonusDouble = Utilities.CalculateYearlyWage(amountDouble, monthsDouble, bonusDouble);

Utilities.UsingOptionalParameters();

Utilities.UsingNamedArguments();

Console.ReadLine();


