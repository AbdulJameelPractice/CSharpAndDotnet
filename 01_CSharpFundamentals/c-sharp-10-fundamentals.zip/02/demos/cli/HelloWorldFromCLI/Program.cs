﻿// See https://aka.ms/new-console-template for more information

string name = "Gill";

Console.WriteLine("Hello " + name);
