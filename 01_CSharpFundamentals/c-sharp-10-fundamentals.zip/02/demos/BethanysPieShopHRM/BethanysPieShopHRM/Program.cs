﻿// See https://aka.ms/new-console-template for more information

string name = "Gill";
string lastName = "Cleeren";

Console.WriteLine("Hello " + name + " " + lastName);



